export type UserRole = "client" | "freelancer" | "arbiter";

export interface RepIdLink {
  repIdAddress: string;
  linkedAt: string;
}

export interface User {
  id: string;
  displayName: string;
  roles: UserRole[];
  walletAddress: string;
  repId?: RepIdLink;
  createdAt: string;
}
