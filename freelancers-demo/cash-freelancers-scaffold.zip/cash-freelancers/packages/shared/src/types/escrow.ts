export type EscrowMode = "bilateral" | "arbitrated";

export type EscrowStatus =
  | "pending_funding"
  | "funded"
  | "released"
  | "refunded"
  | "disputed";

export interface Escrow {
  id: string;
  jobId: string;
  mode: EscrowMode;
  contractAddress: string;
  arbiterId?: string;
  amountSats: number;
  status: EscrowStatus;
  fundingTxid?: string;
  releaseTxid?: string;
  timeoutAt?: string;
}
