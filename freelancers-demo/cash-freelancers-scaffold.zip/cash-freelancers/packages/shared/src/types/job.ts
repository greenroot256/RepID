export type JobStatus =
  | "open"
  | "in_progress"
  | "delivered"
  | "completed"
  | "cancelled";

export interface Job {
  id: string;
  clientId: string;
  title: string;
  description: string;
  budgetSats: number;
  status: JobStatus;
  freelancerId?: string;
  createdAt: string;
  updatedAt: string;
}
