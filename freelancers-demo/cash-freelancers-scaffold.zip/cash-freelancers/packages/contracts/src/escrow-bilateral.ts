import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { compileFile } from "cashc";
import {
  Contract,
  ElectrumNetworkProvider,
  TransactionBuilder,
  placeholderPublicKey,
  placeholderSignature,
  type Network,
  type NetworkProvider,
  type Utxo
} from "cashscript";

// Compiled at load time from the .cash source. For production it's better
// to precompile with `cashc` at build time and version the artifact .json
// instead of compiling on every boot — left as a future improvement, not
// needed for the MVP.
const __dirname = dirname(fileURLToPath(import.meta.url));
const artifact = compileFile(join(__dirname, "escrow-bilateral.cash"));

const MINER_FEE = 1000n; // sats — has to match what the .cash file assumes

export interface EscrowBilateralParams {
  /** hash160(pubkey) of the client — not the full pubkey */
  clientPkh: Uint8Array;
  /** hash160(pubkey) of the freelancer — not the full pubkey */
  freelancerPkh: Uint8Array;
  /** nLockTime: block height or unix timestamp after which the freelancer
   *  can reclaim without the client's signature. CashScript encodes `int`
   *  arguments as `bigint`, not `number`. */
  timeout: bigint;
  network?: Network;
  /** Inject a custom provider (e.g. `MockNetworkProvider` for tests).
   *  Defaults to `new ElectrumNetworkProvider(network)`. */
  provider?: NetworkProvider;
}

export type EscrowBilateralContract = ReturnType<typeof createEscrowBilateralContract>;

/**
 * Instantiates the EscrowBilateral contract and returns CashScript's
 * `Contract` object (exposes `.address`, `.getUtxos()`,
 * `.unlock.release(...)`, `.unlock.reclaim(...)`, etc.).
 */
export function createEscrowBilateralContract({
  clientPkh,
  freelancerPkh,
  timeout,
  network = "mainnet",
  provider = new ElectrumNetworkProvider(network)
}: EscrowBilateralParams) {
  return new Contract(artifact, [clientPkh, freelancerPkh, timeout], { provider });
}

/**
 * Builds the "release" transaction (the client approves and releases the
 * payment to the freelancer) as a WalletConnect BCH object, ready to ask
 * the client's wallet for a signature — see `signTransaction` in
 * `@cash-freelancers/wallet-connect`.
 *
 * Doesn't sign anything here: the client's pubkey and signature are left
 * as placeholders (`placeholderPublicKey`/`placeholderSignature`) that
 * the wallet fills in when signing, following the convention documented
 * at https://github.com/mainnet-pat/wc2-bch-bcr
 */
export async function buildReleaseWcTransaction(
  contract: EscrowBilateralContract,
  freelancerAddress: string,
  utxo?: Utxo
) {
  const fundingUtxo = utxo ?? (await contract.getUtxos())[0];
  if (!fundingUtxo) {
    throw new Error("The escrow contract has no funds to release");
  }

  const amount = fundingUtxo.satoshis - MINER_FEE;

  const txBuilder = new TransactionBuilder({ provider: contract.provider });
  txBuilder
    .addInput(fundingUtxo, contract.unlock.release(placeholderPublicKey(), placeholderSignature()))
    .addOutput({ to: freelancerAddress, amount });

  return txBuilder.generateWcTransactionObject({
    userPrompt: "Approve and release the payment to the freelancer"
  });
}

/**
 * Same as `buildReleaseWcTransaction`, but for the `reclaim` path: signed
 * by the freelancer, and only valid once the contract's `timeout` has
 * passed.
 */
export async function buildReclaimWcTransaction(
  contract: EscrowBilateralContract,
  freelancerAddress: string,
  utxo?: Utxo
) {
  const fundingUtxo = utxo ?? (await contract.getUtxos())[0];
  if (!fundingUtxo) {
    throw new Error("The escrow contract has no funds to reclaim");
  }

  const amount = fundingUtxo.satoshis - MINER_FEE;

  const txBuilder = new TransactionBuilder({ provider: contract.provider });
  txBuilder
    .addInput(fundingUtxo, contract.unlock.reclaim(placeholderPublicKey(), placeholderSignature()))
    .addOutput({ to: freelancerAddress, amount });

  return txBuilder.generateWcTransactionObject({
    userPrompt: "Claim the payment (the client's approval window expired)"
  });
}

export { artifact as escrowBilateralArtifact };
export type { Network } from "cashscript";

/**
 * Broadcasts an already fully-signed raw transaction (hex) to the
 * network. Kept here so apps/api doesn't need `cashscript` as a direct
 * dependency — everything BCH-network-related goes through this
 * package.
 */
export async function broadcastRawTransaction(txHex: string, network: Network = "mainnet"): Promise<string> {
  const provider = new ElectrumNetworkProvider(network);
  return provider.sendRawTransaction(txHex);
}
