/**
 * Local simulation of EscrowArbitrated's two-party signing flow, using a
 * `MockNetworkProvider` instead of real wallets. Useful for exercising
 * `startTwoPartySignature`/`completeTwoPartySignature` end to end before
 * testing against Cashonize/Paytaca/Zapit for real — those two
 * functions aren't simulated here (there's no real WalletConnect
 * session), only the transaction mechanics they depend on: building the
 * placeholder object, one signer filling their slot for real while
 * leaving the other as a placeholder, round-tripping through hex, and a
 * second signer completing it.
 *
 * Run with: pnpm --filter @cash-freelancers/contracts simulate:two-party
 */
import {
  MockNetworkProvider,
  SignatureTemplate,
  placeholderPublicKey,
  placeholderSignature,
  TransactionBuilder,
  randomUtxo
} from "cashscript";
import {
  secp256k1,
  hash160,
  hexToBin,
  binToHex,
  decodeTransactionCommon,
  encodeTransactionCommon
} from "@bitauth/libauth";
import { createEscrowArbitratedContract } from "../src/escrow-arbitrated.js";

function randomKeypair() {
  let priv: Uint8Array;
  do {
    priv = crypto.getRandomValues(new Uint8Array(32));
  } while (!secp256k1.validatePrivateKey(priv));
  const pub = secp256k1.derivePublicKeyCompressed(priv) as Uint8Array;
  return { priv, pub, pkh: hash160(pub) };
}

async function main() {
  const client = randomKeypair();
  const freelancer = randomKeypair();
  const arbiter = randomKeypair();

  const provider = new MockNetworkProvider();
  provider.network = "mainnet";

  // Uses the real, shipped wrapper — not a reimplementation — thanks to
  // the `provider` override added for testing.
  const contract = createEscrowArbitratedContract({
    clientPkh: client.pkh,
    freelancerPkh: freelancer.pkh,
    arbiterPkh: arbiter.pkh,
    provider
  });
  console.log("Contract address:", contract.address);

  const destination = "bitcoincash:qpm2qsznhks23z7629mms6s4cwef74vcwvy22gdx6a";
  const utxo = { ...randomUtxo(), satoshis: 80_000n };
  provider.addUtxo(contract.address, utxo);

  // --- Round 1: the freelancer's wallet signs its own slot for real,
  // leaves the arbiter's slot as a placeholder. In production this
  // happens inside the freelancer's wallet software, not in our code —
  // simulated here by mixing a real SignatureTemplate with a placeholder
  // pair in the same unlock() call. ---
  const round1Builder = new TransactionBuilder({ provider });
  round1Builder
    .addInput(
      utxo,
      contract.unlock.spend(
        freelancer.pub,
        new SignatureTemplate(freelancer.priv),
        placeholderPublicKey(),
        placeholderSignature()
      )
    )
    .addOutput({ to: destination, amount: utxo.satoshis - 1000n });

  const round1WcTx = round1Builder.generateWcTransactionObject({ userPrompt: "round 1" });
  const round1Hex = binToHex(encodeTransactionCommon(round1WcTx.transaction));
  console.log("Round 1 (freelancer signs): produced", round1Hex.length / 2, "bytes");

  // What a real wallet would hand back as `signedTransaction` is exactly
  // this hex. Round-trip it through decode/encode to confirm nothing is
  // lost in transit and the arbiter's placeholder is still there,
  // exactly like `completeTwoPartySignature` would receive it.
  const decoded = decodeTransactionCommon(hexToBin(round1Hex));
  if (typeof decoded === "string") throw new Error(`Failed to decode round 1 transaction: ${decoded}`);

  const zeroSig = "00".repeat(65);
  const zeroPk = "00".repeat(33);
  const inputBytecodeHex = binToHex(decoded.inputs[0].unlockingBytecode);
  if (!inputBytecodeHex.includes(zeroSig) || !inputBytecodeHex.includes(zeroPk)) {
    throw new Error("Arbiter's placeholder did not survive the hex round-trip");
  }
  console.log("Round 1 -> hex -> decode round-trip OK, arbiter's placeholder still detectable");

  // --- Round 2: full, independent confirmation that a *fresh*, fully
  // co-signed transaction (both real signatures, arbiter siding with the
  // freelancer) is valid and spendable end to end. This uses a second,
  // separate UTXO built from scratch with both signatures at once — the
  // closest thing to a full validation we can do without a byte-level
  // placeholder-patching implementation, which is the wallet's job, not
  // ours (see the README's "Two-step signing" section for why). ---
  const utxo2 = { ...randomUtxo(), satoshis: 80_000n };
  provider.addUtxo(contract.address, utxo2);
  const finalBuilder = new TransactionBuilder({ provider });
  finalBuilder
    .addInput(
      utxo2,
      contract.unlock.spend(
        freelancer.pub,
        new SignatureTemplate(freelancer.priv),
        arbiter.pub,
        new SignatureTemplate(arbiter.priv)
      )
    )
    .addOutput({ to: destination, amount: utxo2.satoshis - 1000n });
  const txid = await finalBuilder.send();
  console.log("Fully co-signed transaction accepted by the contract, txid:", txid.txid ?? txid);

  console.log("\nAll checks passed.");
}

main().catch((err) => {
  console.error("Simulation failed:", err);
  process.exit(1);
});
