// The "WC2-BCH" convention: the WalletConnect v2 profile for Bitcoin Cash
// that Cashonize, Paytaca and Zapit support today. It is not (yet) a
// formal BCH standard — it's a community convention documented by its
// author here: https://github.com/mainnet-pat/wc2-bch-bcr
// It may keep evolving; worth checking that source from time to time.

export type BchNetwork = "mainnet" | "testnet" | "regtest";

// Chain identifiers in CAIP-2 format.
const CHAIN_BY_NETWORK: Record<BchNetwork, string> = {
  mainnet: "bch:bitcoincash",
  testnet: "bch:bchtest",
  regtest: "bch:bchreg"
};

export function bchChainId(network: BchNetwork = "mainnet"): string {
  return CHAIN_BY_NETWORK[network];
}

export function bchRequiredNamespaces(network: BchNetwork = "mainnet") {
  return {
    bch: {
      chains: [CHAIN_BY_NETWORK[network]],
      methods: ["bch_getAddresses", "bch_signTransaction", "bch_signMessage"],
      events: ["addressesChanged"]
    }
  };
}
