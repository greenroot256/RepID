// App/dapp-side types for the WC2-BCH convention. They mirror what
// https://github.com/mainnet-pat/wc2-bch-bcr documents — the connected
// wallet (Cashonize/Paytaca/Zapit) is the one that interprets them.

export interface WalletSession {
  topic: string;
  address: string;
  network: "mainnet" | "testnet" | "regtest";
}

// Structural shape of the object returned by
// `TransactionBuilder.generateWcTransactionObject()` from `cashscript`.
// Typed here instead of importing `cashscript` directly so this package
// (transport/pairing) doesn't depend on the contracts package — whoever
// builds the transaction (`@cash-freelancers/contracts`) constructs it
// and hands it to `signTransaction` as-is.
export interface WcTransactionObjectLike {
  transaction: unknown;
  sourceOutputs: unknown[];
  broadcast?: boolean;
  userPrompt?: string;
}

export interface WcSignTransactionResponse {
  signedTransaction: string;
  signedTransactionHash: string;
}

export interface WcSignMessageRequest {
  message: string;
  userPrompt?: string;
}

export type WcSignMessageResponse = string;
