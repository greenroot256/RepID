"use client";

import { useCallback, useEffect, useState } from "react";
import QRCode from "qrcode";
import {
  connectWallet,
  disconnectWallet,
  restoreSession,
  type WalletSession
} from "@cash-freelancers/wallet-connect";

const SESSION_STORAGE_KEY = "cash-freelancers:wc-topic";

const walletConnectConfig = {
  projectId: process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID ?? "",
  network: "mainnet" as const,
  metadata: {
    name: "Cash Freelancers",
    description: "A freelance marketplace with payments on Bitcoin Cash",
    url: "https://cashfreelancers.example",
    icons: []
  }
};

type Status = "idle" | "connecting" | "error";

export function ConnectWalletButton() {
  const [session, setSession] = useState<WalletSession | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>("idle");

  // On page load, try to restore a previous session (only the topic is
  // saved in localStorage — never keys or sensitive data).
  useEffect(() => {
    const savedTopic = window.localStorage.getItem(SESSION_STORAGE_KEY);
    if (!savedTopic) return;

    restoreSession(walletConnectConfig, savedTopic)
      .then((restored) => {
        if (restored) setSession(restored);
        else window.localStorage.removeItem(SESSION_STORAGE_KEY);
      })
      .catch(() => window.localStorage.removeItem(SESSION_STORAGE_KEY));
  }, []);

  const handleConnect = useCallback(async () => {
    setStatus("connecting");
    try {
      const { uri, approval } = await connectWallet(walletConnectConfig);
      setQrDataUrl(await QRCode.toDataURL(uri));

      const approved = await approval();
      window.localStorage.setItem(SESSION_STORAGE_KEY, approved.topic);
      setSession(approved);
      setQrDataUrl(null);
      setStatus("idle");
    } catch (err) {
      console.error(err);
      setStatus("error");
      setQrDataUrl(null);
    }
  }, []);

  const handleDisconnect = useCallback(async () => {
    if (!session) return;
    await disconnectWallet(walletConnectConfig, session.topic);
    window.localStorage.removeItem(SESSION_STORAGE_KEY);
    setSession(null);
  }, [session]);

  if (session) {
    return (
      <div className="wallet-box">
        <p>
          Connected wallet: <code>{session.address}</code>
        </p>
        <button onClick={handleDisconnect}>Disconnect</button>
      </div>
    );
  }

  return (
    <div className="wallet-box">
      <button onClick={handleConnect} disabled={status === "connecting"}>
        {status === "connecting" ? "Connecting…" : "Connect wallet"}
      </button>
      {qrDataUrl && (
        <div className="wallet-qr">
          <p>Scan with Cashonize, Paytaca or Zapit:</p>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={qrDataUrl} alt="WalletConnect pairing QR code" width={220} height={220} />
        </div>
      )}
      {status === "error" && <p role="alert">Couldn&apos;t connect. Try again.</p>}
    </div>
  );
}
