import { ConnectWalletButton } from "./components/ConnectWalletButton";

export default function HomePage() {
  return (
    <main>
      <h1>Cash Freelancers</h1>
      <p>
        A freelance marketplace with global payments on Bitcoin Cash:
        minimal fees, on-chain escrow, and reputation you can carry with
        you via RepID.
      </p>
      <ConnectWalletButton />
      <section>
        <h2>Next steps</h2>
        <ul>
          <li>API repositories/endpoints that use the data model</li>
          <li>Arbitrated escrow contract (2-of-3, with an arbiter)</li>
          <li>Sign the escrow release/reclaim from the connected wallet</li>
        </ul>
      </section>
    </main>
  );
}
