import "./globals.css";
import type { ReactNode } from "react";

export const metadata = {
  title: "Cash Freelancers",
  description: "A freelance marketplace with payments on Bitcoin Cash"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
