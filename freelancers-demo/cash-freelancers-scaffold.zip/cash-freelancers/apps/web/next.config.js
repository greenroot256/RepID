/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ["@cash-freelancers/shared", "@cash-freelancers/wallet-connect"]
};

module.exports = nextConfig;
