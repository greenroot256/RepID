import { decodeCashAddress } from "@bitauth/libauth";

/**
 * Derives the public-key hash (pkh) from a P2PKH cashaddress. We store
 * `wallet_address` on `users` and derive the pkh on the fly wherever a
 * contract needs it (clientPkh/freelancerPkh/arbiterPkh), instead of
 * storing the pkh a second time — the address already encodes it.
 */
export function pkhFromAddress(address: string): Uint8Array {
  const decoded = decodeCashAddress(address);
  if (typeof decoded === "string") {
    throw new Error(`Invalid cashaddress "${address}": ${decoded}`);
  }
  if (decoded.type !== "p2pkh") {
    throw new Error(`Expected a P2PKH cashaddress, got type "${decoded.type}"`);
  }
  return decoded.payload;
}
