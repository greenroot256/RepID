import type { FastifyInstance } from "fastify";
import { jobsRepo, proposalsRepo } from "../db/repositories/index.js";
import { requireAuth } from "../auth/session.js";

interface CreateProposalBody {
  message?: string;
  proposedAmountSats: number;
}

export async function proposalRoutes(app: FastifyInstance) {
  app.post<{ Params: { jobId: string }; Body: CreateProposalBody }>(
    "/jobs/:jobId/proposals",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const proposal = await proposalsRepo.createProposal({
          jobId: request.params.jobId,
          freelancerId: request.authenticatedUserId!,
          ...request.body
        });
        reply.status(201).send(proposal);
      } catch (err) {
        app.log.error(err);
        reply.status(422).send({ error: (err as Error).message });
      }
    }
  );

  app.get<{ Params: { jobId: string } }>("/jobs/:jobId/proposals", async (request, reply) => {
    const proposals = await proposalsRepo.findProposalsByJob(request.params.jobId);
    reply.send(proposals);
  });

  app.post<{ Params: { id: string } }>(
    "/proposals/:id/accept",
    { preHandler: requireAuth },
    async (request, reply) => {
      const proposal = await proposalsRepo.findProposalById(request.params.id);
      if (!proposal) {
        reply.status(404).send({ error: "Proposal not found" });
        return;
      }
      const job = await jobsRepo.findJobById(proposal.jobId);
      if (!job || job.clientId !== request.authenticatedUserId) {
        reply.status(403).send({ error: "Only this job's client can accept a proposal" });
        return;
      }
      const accepted = await proposalsRepo.acceptProposal(request.params.id);
      reply.send(accepted);
    }
  );

  app.post<{ Params: { id: string } }>(
    "/proposals/:id/reject",
    { preHandler: requireAuth },
    async (request, reply) => {
      const proposal = await proposalsRepo.findProposalById(request.params.id);
      if (!proposal) {
        reply.status(404).send({ error: "Proposal not found" });
        return;
      }
      const job = await jobsRepo.findJobById(proposal.jobId);
      if (!job || job.clientId !== request.authenticatedUserId) {
        reply.status(403).send({ error: "Only this job's client can reject a proposal" });
        return;
      }
      const rejected = await proposalsRepo.updateProposalStatus(request.params.id, "rejected");
      reply.send(rejected);
    }
  );
}
