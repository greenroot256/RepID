import type { FastifyInstance } from "fastify";
import { ratingsRepo } from "../db/repositories/index.js";

interface CreateRatingBody {
  raterId: string;
  rateeId: string;
  score: number;
  comment?: string;
}

export async function ratingRoutes(app: FastifyInstance) {
  app.post<{ Params: { jobId: string }; Body: CreateRatingBody }>(
    "/jobs/:jobId/ratings",
    async (request, reply) => {
      try {
        const rating = await ratingsRepo.createRating({
          jobId: request.params.jobId,
          ...request.body
        });
        reply.status(201).send(rating);
      } catch (err) {
        app.log.error(err);
        reply.status(422).send({ error: (err as Error).message });
      }
    }
  );

  app.get<{ Params: { id: string } }>("/users/:id/ratings", async (request, reply) => {
    const ratings = await ratingsRepo.findRatingsForUser(request.params.id);
    reply.send(ratings);
  });
}
