import type { FastifyInstance } from "fastify";
import { randomUUID } from "node:crypto";
import { authRepo, usersRepo } from "../db/repositories/index.js";
import { verifyMessage } from "../utils/bch-message.js";
import { generateSessionToken, hashToken, requireAuth, SESSION_TTL_MS } from "../auth/session.js";

const CHALLENGE_TTL_MS = 5 * 60 * 1000; // 5 minutes

export async function authRoutes(app: FastifyInstance) {
  // Step 1: get a one-time message to sign. Doesn't require the wallet
  // to belong to an existing user yet — signing it is what proves
  // ownership, in step 2.
  app.post<{ Body: { walletAddress: string } }>("/auth/challenge", async (request, reply) => {
    const { walletAddress } = request.body;
    const nonce = randomUUID();
    const message =
      "Cash Freelancers wants you to sign in.\n\n" +
      `Wallet: ${walletAddress}\n` +
      `Nonce: ${nonce}\n` +
      `Issued: ${new Date().toISOString()}`;

    const challenge = await authRepo.createChallenge({
      walletAddress,
      nonce,
      message,
      expiresAt: new Date(Date.now() + CHALLENGE_TTL_MS)
    });

    // The frontend passes `message` to signMessage() from
    // @cash-freelancers/wallet-connect to get it signed by the wallet
    // that approved the WalletConnect session.
    reply.status(201).send({ challengeId: challenge.id, message });
  });

  // Step 2: hand back the signature. If it checks out, get a session
  // token — creating the user first if this wallet has never been seen
  // before (the wallet itself is the proof of identity; there's no
  // separate sign-up step).
  app.post<{ Body: { challengeId: string; signature: string } }>(
    "/auth/verify",
    async (request, reply) => {
      const { challengeId, signature } = request.body;
      const challenge = await authRepo.findChallengeById(challengeId);

      if (!challenge) {
        reply.status(404).send({ error: "Challenge not found" });
        return;
      }
      if (challenge.usedAt) {
        reply.status(409).send({ error: "Challenge was already used" });
        return;
      }
      if (challenge.expiresAt.getTime() < Date.now()) {
        reply.status(410).send({ error: "Challenge expired" });
        return;
      }

      const valid = verifyMessage(challenge.message, signature, challenge.walletAddress);
      if (!valid) {
        reply.status(401).send({ error: "Signature does not match the challenge and wallet" });
        return;
      }
      await authRepo.markChallengeUsed(challenge.id);

      let user = await usersRepo.findUserByWalletAddress(challenge.walletAddress);
      if (!user) {
        user = await usersRepo.createUser({
          displayName: `${challenge.walletAddress.slice(0, 18)}…`,
          walletAddress: challenge.walletAddress,
          roles: []
        });
      }

      const token = generateSessionToken();
      await authRepo.createSession({
        userId: user.id,
        tokenHash: hashToken(token),
        expiresAt: new Date(Date.now() + SESSION_TTL_MS)
      });

      reply.send({ token, user });
    }
  );

  app.post("/auth/logout", { preHandler: requireAuth }, async (request, reply) => {
    await authRepo.deleteSession(request.sessionTokenHash!);
    reply.status(204).send();
  });

  app.get("/auth/me", { preHandler: requireAuth }, async (request, reply) => {
    const user = await usersRepo.findUserById(request.authenticatedUserId!);
    reply.send(user);
  });
}
