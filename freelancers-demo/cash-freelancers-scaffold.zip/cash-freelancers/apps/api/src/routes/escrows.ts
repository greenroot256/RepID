import type { FastifyInstance } from "fastify";
import { stringify } from "@bitauth/libauth";
import {
  createEscrowBilateralContract,
  createEscrowArbitratedContract,
  buildReleaseWcTransaction,
  buildReclaimWcTransaction,
  buildSpendWcTransaction,
  broadcastRawTransaction,
  type Network
} from "@cash-freelancers/contracts";
import type { EscrowMode } from "@cash-freelancers/shared";
import { escrowsRepo, jobsRepo, usersRepo } from "../db/repositories/index.js";
import { pkhFromAddress } from "../utils/address.js";
import { requireAuth } from "../auth/session.js";

interface CreateEscrowBody {
  jobId: string;
  mode: EscrowMode;
  amountSats: number;
  arbiterId?: string;
  timeoutAt?: string; // ISO date, required for "bilateral"
}

/** Re-derives the escrow's on-chain contract from its DB record — same
 *  parties, same mode, always the same address as when it was created.
 *  Used by every route below instead of trusting a client-supplied
 *  contract address. */
async function loadEscrowContract(escrowId: string) {
  const escrow = await escrowsRepo.findEscrowById(escrowId);
  if (!escrow) return undefined;

  const job = await jobsRepo.findJobById(escrow.jobId);
  if (!job || !job.freelancerId) throw new Error(`Job for escrow ${escrowId} is incomplete`);

  const [client, freelancer] = await Promise.all([
    usersRepo.findUserById(job.clientId),
    usersRepo.findUserById(job.freelancerId)
  ]);
  if (!client || !freelancer) throw new Error(`Client or freelancer for escrow ${escrowId} not found`);

  if (escrow.mode === "bilateral") {
    if (!escrow.timeoutAt) throw new Error(`Bilateral escrow ${escrowId} has no timeout stored`);
    const contract = createEscrowBilateralContract({
      clientPkh: pkhFromAddress(client.walletAddress),
      freelancerPkh: pkhFromAddress(freelancer.walletAddress),
      timeout: BigInt(Math.floor(new Date(escrow.timeoutAt).getTime() / 1000))
    });
    return { escrow, job, client, freelancer, contract };
  }

  if (!escrow.arbiterId) throw new Error(`Arbitrated escrow ${escrowId} has no arbiter stored`);
  const arbiter = await usersRepo.findUserById(escrow.arbiterId);
  if (!arbiter) throw new Error(`Arbiter for escrow ${escrowId} not found`);
  const contract = createEscrowArbitratedContract({
    clientPkh: pkhFromAddress(client.walletAddress),
    freelancerPkh: pkhFromAddress(freelancer.walletAddress),
    arbiterPkh: pkhFromAddress(arbiter.walletAddress)
  });
  return { escrow, job, client, freelancer, arbiter, contract };
}

export async function escrowRoutes(app: FastifyInstance) {
  app.post<{ Body: CreateEscrowBody }>("/escrows", { preHandler: requireAuth }, async (request, reply) => {
    try {
      const job = await jobsRepo.findJobById(request.body.jobId);
      if (!job) {
        reply.status(404).send({ error: "Job not found" });
        return;
      }
      if (job.clientId !== request.authenticatedUserId) {
        reply.status(403).send({ error: "Only this job's client can open an escrow for it" });
        return;
      }
      const { timeoutAt, ...rest } = request.body;
      const escrow = await escrowsRepo.createEscrow({
        ...rest,
        timeoutAt: timeoutAt ? new Date(timeoutAt) : undefined
      });
      reply.status(201).send(escrow);
    } catch (err) {
      app.log.error(err);
      reply.status(422).send({ error: (err as Error).message });
    }
  });

  app.get<{ Params: { id: string } }>("/escrows/:id", async (request, reply) => {
    const escrow = await escrowsRepo.findEscrowById(request.params.id);
    if (!escrow) {
      reply.status(404).send({ error: "Escrow not found" });
      return;
    }
    reply.send(escrow);
  });

  app.get<{ Params: { id: string } }>("/escrows/:id/release-transaction", async (request, reply) => {
    try {
      const loaded = await loadEscrowContract(request.params.id);
      if (!loaded) return reply.status(404).send({ error: "Escrow not found" });
      if (loaded.escrow.mode !== "bilateral") {
        return reply.status(400).send({ error: "This escrow is not bilateral" });
      }
      const wcTransactionObject = await buildReleaseWcTransaction(
        loaded.contract,
        loaded.freelancer.walletAddress
      );
      reply.send(JSON.parse(stringify({ contractAddress: loaded.contract.address, wcTransactionObject })));
    } catch (err) {
      app.log.error(err);
      reply.status(422).send({ error: (err as Error).message });
    }
  });

  app.get<{ Params: { id: string } }>("/escrows/:id/reclaim-transaction", async (request, reply) => {
    try {
      const loaded = await loadEscrowContract(request.params.id);
      if (!loaded) return reply.status(404).send({ error: "Escrow not found" });
      if (loaded.escrow.mode !== "bilateral") {
        return reply.status(400).send({ error: "This escrow is not bilateral" });
      }
      const wcTransactionObject = await buildReclaimWcTransaction(
        loaded.contract,
        loaded.freelancer.walletAddress
      );
      reply.send(JSON.parse(stringify({ contractAddress: loaded.contract.address, wcTransactionObject })));
    } catch (err) {
      app.log.error(err);
      reply.status(422).send({ error: (err as Error).message });
    }
  });

  app.get<{ Params: { id: string }; Querystring: { outcome: "release" | "refund" } }>(
    "/escrows/:id/arbitrated-spend-transaction",
    async (request, reply) => {
      try {
        const loaded = await loadEscrowContract(request.params.id);
        if (!loaded) return reply.status(404).send({ error: "Escrow not found" });
        if (loaded.escrow.mode !== "arbitrated") {
          return reply.status(400).send({ error: "This escrow is not arbitrated" });
        }
        const { outcome } = request.query;
        if (outcome !== "release" && outcome !== "refund") {
          return reply.status(400).send({ error: "outcome must be 'release' or 'refund'" });
        }
        const destination =
          outcome === "release" ? loaded.freelancer.walletAddress : loaded.client.walletAddress;
        const wcTransactionObject = await buildSpendWcTransaction(loaded.contract, destination);
        reply.send(JSON.parse(stringify({ contractAddress: loaded.contract.address, wcTransactionObject })));
      } catch (err) {
        app.log.error(err);
        reply.status(422).send({ error: (err as Error).message });
      }
    }
  );

  // --- Two-step co-signing (EscrowArbitrated.spend only) ---
  // See startTwoPartySignature/completeTwoPartySignature in
  // @cash-freelancers/wallet-connect and the root README's "Two-step
  // signing" section.

  app.post<{
    Params: { id: string };
    Body: { signedTransactionHex: string; signedBy: string; outcome: "release" | "refund" };
  }>("/escrows/:id/arbitrated-spend/first-signature", async (request, reply) => {
    await escrowsRepo.savePendingSignature({
      escrowId: request.params.id,
      signedTransactionHex: request.body.signedTransactionHex,
      signedBy: request.body.signedBy,
      outcome: request.body.outcome
    });
    reply.status(204).send();
  });

  app.get<{ Params: { id: string } }>(
    "/escrows/:id/arbitrated-spend/pending",
    async (request, reply) => {
      try {
        const pending = await escrowsRepo.getPendingSignature(request.params.id);
        if (!pending) return reply.status(404).send({ error: "No pending signature for this escrow" });

        const loaded = await loadEscrowContract(request.params.id);
        if (!loaded) return reply.status(404).send({ error: "Escrow not found" });

        const destination =
          pending.outcome === "release" ? loaded.freelancer.walletAddress : loaded.client.walletAddress;
        // Only used to regenerate matching sourceOutputs — its freshly
        // generated `transaction` field is discarded in favor of the
        // stored, partially-signed hex.
        const fresh = await buildSpendWcTransaction(loaded.contract, destination);

        reply.send(
          JSON.parse(
            stringify({
              transaction: pending.signedTransactionHex,
              sourceOutputs: fresh.sourceOutputs,
              outcome: pending.outcome
            })
          )
        );
      } catch (err) {
        app.log.error(err);
        reply.status(422).send({ error: (err as Error).message });
      }
    }
  );

  app.post<{
    Params: { id: string };
    Body: { signedTransactionHex: string; signedTransactionHash: string };
  }>("/escrows/:id/arbitrated-spend/final-signature", async (request, reply) => {
    const pending = await escrowsRepo.getPendingSignature(request.params.id);
    if (!pending) {
      reply.status(409).send({ error: "No pending signature to finalize for this escrow" });
      return;
    }
    const escrow = await escrowsRepo.finalizeEscrow({
      escrowId: request.params.id,
      outcome: pending.outcome,
      releaseTxid: request.body.signedTransactionHash
    });
    reply.send(escrow);
  });

  // --- Broadcasting ---
  // Works against a real BCH network (Electrum) — not reachable from
  // this sandbox, so it couldn't be exercised end to end here. Only
  // needed if the wallet itself wasn't asked to broadcast
  // (`broadcast: true` on the WcTransactionObject).
  app.post<{ Params: { id: string }; Body: { signedTransactionHex: string; network?: Network } }>(
    "/escrows/:id/broadcast",
    async (request, reply) => {
      try {
        const txid = await broadcastRawTransaction(request.body.signedTransactionHex, request.body.network);
        reply.send({ txid });
      } catch (err) {
        app.log.error(err);
        reply.status(502).send({ error: (err as Error).message });
      }
    }
  );
}
