import type { FastifyInstance } from "fastify";
import { arbiterProfilesRepo } from "../db/repositories/index.js";

export async function arbiterRoutes(app: FastifyInstance) {
  app.post<{ Params: { id: string }; Body: { bio?: string; feeBps: number } }>(
    "/users/:id/arbiter-profile",
    async (request, reply) => {
      try {
        const profile = await arbiterProfilesRepo.upsertArbiterProfile({
          userId: request.params.id,
          ...request.body
        });
        reply.status(201).send(profile);
      } catch (err) {
        app.log.error(err);
        reply.status(422).send({ error: (err as Error).message });
      }
    }
  );

  app.get<{ Params: { id: string } }>("/users/:id/arbiter-profile", async (request, reply) => {
    const profile = await arbiterProfilesRepo.findArbiterProfile(request.params.id);
    if (!profile) {
      reply.status(404).send({ error: "This user has no arbiter profile" });
      return;
    }
    reply.send(profile);
  });

  app.get("/arbiters", async (_request, reply) => {
    const arbiters = await arbiterProfilesRepo.listActiveArbiters();
    reply.send(arbiters);
  });
}
