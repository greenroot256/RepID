import type { FastifyInstance } from "fastify";
import type { UserRole } from "@cash-freelancers/shared";
import { usersRepo } from "../db/repositories/index.js";

interface CreateUserBody {
  displayName: string;
  walletAddress: string;
  roles: UserRole[];
}

export async function userRoutes(app: FastifyInstance) {
  app.post<{ Body: CreateUserBody }>("/users", async (request, reply) => {
    try {
      const user = await usersRepo.createUser(request.body);
      reply.status(201).send(user);
    } catch (err) {
      app.log.error(err);
      reply.status(422).send({ error: (err as Error).message });
    }
  });

  app.get<{ Params: { id: string } }>("/users/:id", async (request, reply) => {
    const user = await usersRepo.findUserById(request.params.id);
    if (!user) {
      reply.status(404).send({ error: "User not found" });
      return;
    }
    reply.send(user);
  });

  app.post<{ Params: { id: string }; Body: { repIdAddress: string } }>(
    "/users/:id/repid",
    async (request, reply) => {
      await usersRepo.linkRepId(request.params.id, request.body.repIdAddress);
      reply.status(204).send();
    }
  );
}
