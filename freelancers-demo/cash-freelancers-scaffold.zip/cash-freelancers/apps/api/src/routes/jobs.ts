import type { FastifyInstance } from "fastify";
import { jobsRepo } from "../db/repositories/index.js";
import { requireAuth } from "../auth/session.js";

interface CreateJobBody {
  title: string;
  description: string;
  budgetSats: number;
}

export async function jobRoutes(app: FastifyInstance) {
  app.post<{ Body: CreateJobBody }>("/jobs", { preHandler: requireAuth }, async (request, reply) => {
    try {
      const job = await jobsRepo.createJob({
        ...request.body,
        clientId: request.authenticatedUserId!
      });
      reply.status(201).send(job);
    } catch (err) {
      app.log.error(err);
      reply.status(422).send({ error: (err as Error).message });
    }
  });

  app.get<{ Params: { id: string } }>("/jobs/:id", async (request, reply) => {
    const job = await jobsRepo.findJobById(request.params.id);
    if (!job) {
      reply.status(404).send({ error: "Job not found" });
      return;
    }
    reply.send(job);
  });

  app.post<{ Params: { id: string }; Body: { freelancerId: string } }>(
    "/jobs/:id/assign-freelancer",
    { preHandler: requireAuth },
    async (request, reply) => {
      const job = await jobsRepo.findJobById(request.params.id);
      if (!job) {
        reply.status(404).send({ error: "Job not found" });
        return;
      }
      if (job.clientId !== request.authenticatedUserId) {
        reply.status(403).send({ error: "Only this job's client can assign a freelancer" });
        return;
      }
      const updated = await jobsRepo.assignFreelancer(request.params.id, request.body.freelancerId);
      reply.send(updated);
    }
  );
}
