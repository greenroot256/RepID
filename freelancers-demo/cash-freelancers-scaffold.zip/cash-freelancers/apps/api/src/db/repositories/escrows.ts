import { db } from "../client.js";
import type { Escrow, EscrowMode, EscrowStatus } from "@cash-freelancers/shared";
import { createEscrowBilateralContract, createEscrowArbitratedContract } from "@cash-freelancers/contracts";
import { pkhFromAddress } from "../../utils/address.js";
import { findJobById } from "./jobs.js";
import { findUserById } from "./users.js";

interface EscrowRow {
  id: string;
  job_id: string;
  mode: EscrowMode;
  contract_address: string;
  amount_sats: string;
  status: EscrowStatus;
  arbiter_id: string | null;
  funding_txid: string | null;
  release_txid: string | null;
  timeout_at: Date | null;
  pending_signature_hex: string | null;
  pending_signature_by: string | null;
  pending_outcome: "release" | "refund" | null;
  created_at: Date;
  updated_at: Date;
}

function mapEscrow(row: EscrowRow): Escrow {
  return {
    id: row.id,
    jobId: row.job_id,
    mode: row.mode,
    contractAddress: row.contract_address,
    arbiterId: row.arbiter_id ?? undefined,
    amountSats: Number(row.amount_sats),
    status: row.status,
    fundingTxid: row.funding_txid ?? undefined,
    releaseTxid: row.release_txid ?? undefined,
    timeoutAt: row.timeout_at?.toISOString()
  };
}

/**
 * Creates an escrow for a job. Not a pure CRUD wrapper: it looks up the
 * job's client/freelancer (and arbiter, in arbitrated mode) to derive
 * their pkh from their wallet address and instantiate the real
 * on-chain contract, so `contract_address` is always the actual
 * covenant address, never something the caller has to compute and pass
 * in themselves.
 */
export async function createEscrow(input: {
  jobId: string;
  mode: EscrowMode;
  amountSats: number;
  arbiterId?: string;
  timeoutAt?: Date; // required for "bilateral", ignored for "arbitrated"
}): Promise<Escrow> {
  const job = await findJobById(input.jobId);
  if (!job) throw new Error(`Job ${input.jobId} not found`);
  if (!job.freelancerId) throw new Error(`Job ${input.jobId} has no freelancer assigned yet`);

  const [client, freelancer] = await Promise.all([
    findUserById(job.clientId),
    findUserById(job.freelancerId)
  ]);
  if (!client) throw new Error(`Client ${job.clientId} not found`);
  if (!freelancer) throw new Error(`Freelancer ${job.freelancerId} not found`);

  let contractAddress: string;

  if (input.mode === "bilateral") {
    if (!input.timeoutAt) throw new Error("timeoutAt is required for a bilateral escrow");
    const contract = createEscrowBilateralContract({
      clientPkh: pkhFromAddress(client.walletAddress),
      freelancerPkh: pkhFromAddress(freelancer.walletAddress),
      timeout: BigInt(Math.floor(input.timeoutAt.getTime() / 1000))
    });
    contractAddress = contract.address;
  } else {
    if (!input.arbiterId) throw new Error("arbiterId is required for an arbitrated escrow");
    const arbiter = await findUserById(input.arbiterId);
    if (!arbiter) throw new Error(`Arbiter ${input.arbiterId} not found`);
    const contract = createEscrowArbitratedContract({
      clientPkh: pkhFromAddress(client.walletAddress),
      freelancerPkh: pkhFromAddress(freelancer.walletAddress),
      arbiterPkh: pkhFromAddress(arbiter.walletAddress)
    });
    contractAddress = contract.address;
  }

  const { rows } = await db.query<EscrowRow>(
    `INSERT INTO escrows (job_id, mode, contract_address, amount_sats, arbiter_id, timeout_at)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
    [
      input.jobId,
      input.mode,
      contractAddress,
      input.amountSats,
      input.arbiterId ?? null,
      input.timeoutAt ?? null
    ]
  );
  return mapEscrow(rows[0]);
}

export async function findEscrowById(id: string): Promise<Escrow | undefined> {
  const { rows } = await db.query<EscrowRow>("SELECT * FROM escrows WHERE id = $1", [id]);
  return rows[0] ? mapEscrow(rows[0]) : undefined;
}

export async function findEscrowByJobId(jobId: string): Promise<Escrow | undefined> {
  const { rows } = await db.query<EscrowRow>("SELECT * FROM escrows WHERE job_id = $1", [jobId]);
  return rows[0] ? mapEscrow(rows[0]) : undefined;
}

export async function updateEscrowStatus(id: string, status: EscrowStatus): Promise<Escrow | undefined> {
  const { rows } = await db.query<EscrowRow>(
    "UPDATE escrows SET status = $2, updated_at = now() WHERE id = $1 RETURNING *",
    [id, status]
  );
  return rows[0] ? mapEscrow(rows[0]) : undefined;
}

export async function markFunded(id: string, fundingTxid: string): Promise<Escrow | undefined> {
  const { rows } = await db.query<EscrowRow>(
    `UPDATE escrows SET status = 'funded', funding_txid = $2, updated_at = now()
     WHERE id = $1 RETURNING *`,
    [id, fundingTxid]
  );
  return rows[0] ? mapEscrow(rows[0]) : undefined;
}

/** Step 1 of the two-step co-signing flow: persists the first
 *  co-signer's partially-signed transaction until the second co-signer
 *  is ready. See startTwoPartySignature/completeTwoPartySignature in
 *  @cash-freelancers/wallet-connect. */
export async function savePendingSignature(input: {
  escrowId: string;
  signedTransactionHex: string;
  signedBy: string;
  outcome: "release" | "refund";
}): Promise<void> {
  await db.query(
    `UPDATE escrows
     SET pending_signature_hex = $2, pending_signature_by = $3, pending_outcome = $4, updated_at = now()
     WHERE id = $1`,
    [input.escrowId, input.signedTransactionHex, input.signedBy, input.outcome]
  );
}

export async function getPendingSignature(escrowId: string): Promise<
  { signedTransactionHex: string; signedBy: string; outcome: "release" | "refund" } | undefined
> {
  const { rows } = await db.query<{
    pending_signature_hex: string | null;
    pending_signature_by: string | null;
    pending_outcome: "release" | "refund" | null;
  }>(
    "SELECT pending_signature_hex, pending_signature_by, pending_outcome FROM escrows WHERE id = $1",
    [escrowId]
  );
  const row = rows[0];
  if (!row?.pending_signature_hex || !row.pending_signature_by || !row.pending_outcome) {
    return undefined;
  }
  return {
    signedTransactionHex: row.pending_signature_hex,
    signedBy: row.pending_signature_by,
    outcome: row.pending_outcome
  };
}

/** Step 2 done: records the final signed transaction, sets the escrow's
 *  final status (`released`/`refunded`) based on the outcome that was
 *  stored in step 1, and clears the pending-signature fields. */
export async function finalizeEscrow(input: {
  escrowId: string;
  outcome: "release" | "refund";
  releaseTxid: string;
}): Promise<Escrow | undefined> {
  const status: EscrowStatus = input.outcome === "release" ? "released" : "refunded";
  const { rows } = await db.query<EscrowRow>(
    `UPDATE escrows
     SET status = $2, release_txid = $3,
         pending_signature_hex = NULL, pending_signature_by = NULL, pending_outcome = NULL,
         updated_at = now()
     WHERE id = $1 RETURNING *`,
    [input.escrowId, status, input.releaseTxid]
  );
  return rows[0] ? mapEscrow(rows[0]) : undefined;
}
