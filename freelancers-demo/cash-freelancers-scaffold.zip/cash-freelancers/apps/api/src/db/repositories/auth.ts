import { db } from "../client.js";

interface ChallengeRow {
  id: string;
  wallet_address: string;
  nonce: string;
  message: string;
  expires_at: Date;
  used_at: Date | null;
  created_at: Date;
}

export interface AuthChallenge {
  id: string;
  walletAddress: string;
  nonce: string;
  message: string;
  expiresAt: Date;
  usedAt?: Date;
}

function mapChallenge(row: ChallengeRow): AuthChallenge {
  return {
    id: row.id,
    walletAddress: row.wallet_address,
    nonce: row.nonce,
    message: row.message,
    expiresAt: row.expires_at,
    usedAt: row.used_at ?? undefined
  };
}

export async function createChallenge(input: {
  walletAddress: string;
  nonce: string;
  message: string;
  expiresAt: Date;
}): Promise<AuthChallenge> {
  const { rows } = await db.query<ChallengeRow>(
    `INSERT INTO auth_challenges (wallet_address, nonce, message, expires_at)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [input.walletAddress, input.nonce, input.message, input.expiresAt]
  );
  return mapChallenge(rows[0]);
}

export async function findChallengeById(id: string): Promise<AuthChallenge | undefined> {
  const { rows } = await db.query<ChallengeRow>("SELECT * FROM auth_challenges WHERE id = $1", [id]);
  return rows[0] ? mapChallenge(rows[0]) : undefined;
}

export async function markChallengeUsed(id: string): Promise<void> {
  await db.query("UPDATE auth_challenges SET used_at = now() WHERE id = $1", [id]);
}

export async function createSession(input: {
  userId: string;
  tokenHash: string;
  expiresAt: Date;
}): Promise<void> {
  await db.query(
    "INSERT INTO sessions (user_id, token_hash, expires_at) VALUES ($1, $2, $3)",
    [input.userId, input.tokenHash, input.expiresAt]
  );
}

export async function findSessionByTokenHash(
  tokenHash: string
): Promise<{ userId: string; expiresAt: Date } | undefined> {
  const { rows } = await db.query<{ user_id: string; expires_at: Date }>(
    "SELECT user_id, expires_at FROM sessions WHERE token_hash = $1",
    [tokenHash]
  );
  const row = rows[0];
  return row ? { userId: row.user_id, expiresAt: row.expires_at } : undefined;
}

export async function deleteSession(tokenHash: string): Promise<void> {
  await db.query("DELETE FROM sessions WHERE token_hash = $1", [tokenHash]);
}
