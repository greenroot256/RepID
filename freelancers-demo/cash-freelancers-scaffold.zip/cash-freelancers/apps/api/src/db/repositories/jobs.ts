import { db } from "../client.js";
import type { Job, JobStatus } from "@cash-freelancers/shared";

interface JobRow {
  id: string;
  client_id: string;
  freelancer_id: string | null;
  title: string;
  description: string;
  budget_sats: string; // bigint comes back as string from pg
  status: JobStatus;
  created_at: Date;
  updated_at: Date;
}

function mapJob(row: JobRow): Job {
  return {
    id: row.id,
    clientId: row.client_id,
    freelancerId: row.freelancer_id ?? undefined,
    title: row.title,
    description: row.description,
    budgetSats: Number(row.budget_sats),
    status: row.status,
    createdAt: row.created_at.toISOString(),
    updatedAt: row.updated_at.toISOString()
  };
}

export async function createJob(input: {
  clientId: string;
  title: string;
  description: string;
  budgetSats: number;
}): Promise<Job> {
  const { rows } = await db.query<JobRow>(
    `INSERT INTO jobs (client_id, title, description, budget_sats)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [input.clientId, input.title, input.description, input.budgetSats]
  );
  return mapJob(rows[0]);
}

export async function findJobById(id: string): Promise<Job | undefined> {
  const { rows } = await db.query<JobRow>("SELECT * FROM jobs WHERE id = $1", [id]);
  return rows[0] ? mapJob(rows[0]) : undefined;
}

export async function listJobsByStatus(status: JobStatus): Promise<Job[]> {
  const { rows } = await db.query<JobRow>(
    "SELECT * FROM jobs WHERE status = $1 ORDER BY created_at DESC",
    [status]
  );
  return rows.map(mapJob);
}

export async function assignFreelancer(jobId: string, freelancerId: string): Promise<Job | undefined> {
  const { rows } = await db.query<JobRow>(
    `UPDATE jobs SET freelancer_id = $2, status = 'in_progress', updated_at = now()
     WHERE id = $1 RETURNING *`,
    [jobId, freelancerId]
  );
  return rows[0] ? mapJob(rows[0]) : undefined;
}

export async function updateJobStatus(jobId: string, status: JobStatus): Promise<Job | undefined> {
  const { rows } = await db.query<JobRow>(
    "UPDATE jobs SET status = $2, updated_at = now() WHERE id = $1 RETURNING *",
    [jobId, status]
  );
  return rows[0] ? mapJob(rows[0]) : undefined;
}
