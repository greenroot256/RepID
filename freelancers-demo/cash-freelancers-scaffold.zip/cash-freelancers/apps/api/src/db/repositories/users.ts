import { db } from "../client.js";
import type { User, UserRole } from "@cash-freelancers/shared";

interface UserRow {
  id: string;
  display_name: string;
  wallet_address: string;
  created_at: Date;
}

function mapUser(
  row: UserRow,
  roles: UserRole[],
  repId?: { repid_address: string; linked_at: Date }
): User {
  return {
    id: row.id,
    displayName: row.display_name,
    walletAddress: row.wallet_address,
    roles,
    repId: repId
      ? { repIdAddress: repId.repid_address, linkedAt: repId.linked_at.toISOString() }
      : undefined,
    createdAt: row.created_at.toISOString()
  };
}

async function loadRolesAndRepId(userId: string) {
  const [roleRows, repIdRows] = await Promise.all([
    db.query<{ role: UserRole }>("SELECT role FROM user_roles WHERE user_id = $1", [userId]),
    db.query<{ repid_address: string; linked_at: Date }>(
      "SELECT repid_address, linked_at FROM repid_links WHERE user_id = $1",
      [userId]
    )
  ]);
  return { roles: roleRows.rows.map((r) => r.role), repId: repIdRows.rows[0] };
}

export async function createUser(input: {
  displayName: string;
  walletAddress: string;
  roles: UserRole[];
}): Promise<User> {
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    const { rows } = await client.query<UserRow>(
      "INSERT INTO users (display_name, wallet_address) VALUES ($1, $2) RETURNING *",
      [input.displayName, input.walletAddress]
    );
    const row = rows[0];
    for (const role of input.roles) {
      await client.query("INSERT INTO user_roles (user_id, role) VALUES ($1, $2)", [row.id, role]);
    }
    await client.query("COMMIT");
    return mapUser(row, input.roles);
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

export async function findUserById(id: string): Promise<User | undefined> {
  const { rows } = await db.query<UserRow>("SELECT * FROM users WHERE id = $1", [id]);
  const row = rows[0];
  if (!row) return undefined;
  const { roles, repId } = await loadRolesAndRepId(id);
  return mapUser(row, roles, repId);
}

export async function findUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
  const { rows } = await db.query<UserRow>("SELECT * FROM users WHERE wallet_address = $1", [
    walletAddress
  ]);
  const row = rows[0];
  if (!row) return undefined;
  const { roles, repId } = await loadRolesAndRepId(row.id);
  return mapUser(row, roles, repId);
}

export async function linkRepId(userId: string, repIdAddress: string): Promise<void> {
  await db.query(
    `INSERT INTO repid_links (user_id, repid_address) VALUES ($1, $2)
     ON CONFLICT (user_id) DO UPDATE SET repid_address = EXCLUDED.repid_address, linked_at = now()`,
    [userId, repIdAddress]
  );
}
