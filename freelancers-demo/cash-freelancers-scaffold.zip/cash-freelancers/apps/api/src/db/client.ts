import { Pool } from "pg";

// Placeholder: it's worth adding a connection check on startup later and,
// once they exist, running the data-model migrations here too.
export const db = new Pool({
  connectionString: process.env.DATABASE_URL
});
