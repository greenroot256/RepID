import Fastify from "fastify";
import { healthRoutes } from "./routes/health.js";
import { authRoutes } from "./routes/auth.js";
import { userRoutes } from "./routes/users.js";
import { jobRoutes } from "./routes/jobs.js";
import { escrowRoutes } from "./routes/escrows.js";
import { proposalRoutes } from "./routes/proposals.js";
import { disputeRoutes } from "./routes/disputes.js";
import { ratingRoutes } from "./routes/ratings.js";
import { arbiterRoutes } from "./routes/arbiters.js";

const app = Fastify({ logger: true });

app.register(healthRoutes);
app.register(authRoutes);
app.register(userRoutes);
app.register(jobRoutes);
app.register(escrowRoutes);
app.register(proposalRoutes);
app.register(disputeRoutes);
app.register(ratingRoutes);
app.register(arbiterRoutes);

const port = Number(process.env.PORT ?? 4000);

app.listen({ port, host: "0.0.0.0" }).catch((err) => {
  app.log.error(err);
  process.exit(1);
});
